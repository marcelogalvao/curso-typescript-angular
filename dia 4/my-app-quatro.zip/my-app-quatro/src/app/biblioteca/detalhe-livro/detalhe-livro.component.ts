import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalhe-livro',
  templateUrl: './detalhe-livro.component.html',
  styleUrls: ['./detalhe-livro.component.css']
})
export class DetalheLivroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
