export const environment = {
  production: true,
  url: 'https://treinamento-angular.herokuapp.com/users'
};
