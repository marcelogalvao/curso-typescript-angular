import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-biblioteca',
  templateUrl: './biblioteca.component.html',
  styleUrls: ['./biblioteca.component.css']
})
export class BibliotecaComponent implements OnInit {

  @Output() mudou = new EventEmitter();

  public livro: any = {};
  public livros: Array<any> = [];

  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }

  public onSubmit(form) {
    // console.log(form);

    this.mudou.emit(this.livro.nome);

    const obj = {nome: this.livro.nome, autor: this.livro.autor};
    this.livros.push(obj);
    // this.livro = {};
    form.reset();
  }

  open(content) {
    this.modalService.open(content);
  }

}
