import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { BibliotecaComponent } from './biblioteca.component';
import { DetalheLivroComponent } from './detalhe-livro/detalhe-livro.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [ BibliotecaComponent, DetalheLivroComponent ],
  exports: [ BibliotecaComponent ]
})
export class BibliotecaModule { }
