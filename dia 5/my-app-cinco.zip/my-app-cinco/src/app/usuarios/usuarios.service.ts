import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {

  // private usuarios = ['usuario 1', 'usuario 2', 'usuario 3'];
  private usuarios = [];

  constructor(private http: Http) {
    console.log(environment.production);
  }

  public getUsuarios() {
    // return this.usuarios;
    // return this.http.get('https://treinamento-angular.herokuapp.com/users');
    return this.http.get(environment.url);
  }

  public setUsuario(dados) {
    // this.usuarios.push(str);
    // return this.http.post('https://treinamento-angular.herokuapp.com/users', dados);
    return this.http.post(environment.url, dados);
  }


}
