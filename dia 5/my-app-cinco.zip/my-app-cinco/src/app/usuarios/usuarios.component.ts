import { Component, OnInit } from '@angular/core';
import { UsuariosService } from './usuarios.service';

@Component({
  selector: 'app-usuarios',
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css']
})
export class UsuariosComponent implements OnInit {

  public usuarios: any = [];
  // public nome = '';
  // public email = '';
  public usuario: any = {};

  constructor(private usuariosService: UsuariosService) { }

  ngOnInit() {
    // this.usuarios = this.usuariosService.getUsuarios();
    this.getUsuarios();
  }

  public getUsuarios() {
    this.usuariosService.getUsuarios().subscribe( res => {
      this.usuarios = JSON.parse((<any>res)._body).data;
    });
  }


  public inserir() {
    this.usuariosService.setUsuario(this.usuario).subscribe( res => {
      this.getUsuarios();
    });
  }


}
