import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-biblioteca',
  templateUrl: './biblioteca.component.html',
  styleUrls: ['./biblioteca.component.css']
})
export class BibliotecaComponent implements OnInit {

  // @Input() nome: string;
  @Output() mudou = new EventEmitter();
  @ViewChild('meuInput') inputDOM: ElementRef;

  public livro: string;
  public livros: Array<string> = [];

  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }

  public cadastrar() {

    this.mudou.emit(this.livro);

    this.livros.push(this.livro);
    this.livro = '';

    // console.log(this.inputDOM.nativeElement.value);
    // this.inputDOM.nativeElement.style.backgroundColor = 'red';
  }

  open(content) {
    this.modalService.open(content);
  }

}
