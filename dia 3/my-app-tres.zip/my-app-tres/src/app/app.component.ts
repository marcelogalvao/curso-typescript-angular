import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public title = 'app';
  public nomeLivro: string;


  public novoLivro(str) {
    this.nomeLivro = str;

    // setTimeout( () => {
    //   this.nomeLivro = '';
    // }, 2000);
  }
}
