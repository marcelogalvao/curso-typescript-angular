import { NgModule, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-livros',
  templateUrl: './listar-livros.component.html',
  styleUrls: ['./listar-livros.component.css']
})
export class ListarLivrosComponent implements OnInit {

  descricao: string;
  livro: string;
  livros;
  isRed = false;

  constructor() { }

  ngOnInit() {
    this.livro = 'Digite um livro.';

    this.descricao = 'Livros da minha coleção.';

    this.livros = ['livro 1', 'livro 2', 'livro 3'];
  }


  mudarCor() {
    this.isRed = !this.isRed;
  }

}
