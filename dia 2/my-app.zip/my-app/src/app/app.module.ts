import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListarLivrosComponent } from './listar-livros/listar-livros.component';

@NgModule({
  declarations: [
    AppComponent,
    ListarLivrosComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
